#!/usr/bin/env python
# coding: utf-8

# In[492]:


import numpy as np
import matplotlib.pyplot as plt
from scipy import optimize
from scipy.optimize import curve_fit
import scipy.stats as st
import matplotlib.mlab as mlab


# In[493]:


dro = np.load('dro.npy');
inputEnergy = dro[:,0];
tot_Edep_ECAL = dro[:,1];
tot_cher_ECAL = dro[:,2];
tot_Edep_HCAL = dro[:,3];
tot_cher_HCAL = dro[:,4];


# In[494]:


ene = [120.0,60.0,30.0,15.0,10.0,7.0,5.0,4.0,3.0,2.0,1.0]
nene = len(ene)


# In[495]:


mk0l = 0.49761


# In[496]:


# first loop over all files 
# using only beam energies of 5 and higher
# total_Edep_ECAL < some small number = 0.00001 
# nonzero tot_Edep_HCAL

smallNumber = 0.0001;
minEnergy = 15.0

index = np.where((inputEnergy >= minEnergy) & (tot_Edep_HCAL > 0.0) & (tot_Edep_ECAL < smallNumber))[0]
dro_firstloop = dro[index,:];


# In[497]:


#a) plot the tot_Edep_HCAL/inputEnergy vs. hcal_C_S

tot_Edep_HCAL_1a = dro_firstloop[:,3];
tot_cher_HCAL_1a = dro_firstloop[:,4];

hcal_C_S_1a = tot_cher_HCAL_1a/tot_Edep_HCAL_1a

# beam Energy 
beamEnergy = dro_firstloop[:,0] + mk0l;

# ratio
norm_1a = tot_Edep_HCAL_1a/beamEnergy

#initial plot
plt.plot(hcal_C_S_1a, norm_1a, '.')

# plot trim
nbin=16;
mean, bin_edges, binnumber = st.binned_statistic(hcal_C_S_1a, norm_1a, bins=nbin, statistic='mean') # 
print(len(norm_1a), len(binnumber), np.min(binnumber), np.max(binnumber))

# trim
trim_index = np.where(norm_1a >= 0.8*mean[binnumber-1])[0]
trim_hcal_C_S_1a = hcal_C_S_1a[trim_index]
trim_norm_1a = norm_1a[trim_index]

count, bin_edges, binnumber = st.binned_statistic(trim_hcal_C_S_1a, trim_norm_1a, bins=nbin, statistic='count')
mean, bin_edges, binnumber = st.binned_statistic(trim_hcal_C_S_1a, trim_norm_1a, bins=nbin, statistic='mean')
rms, bin_edges, binnumber = st.binned_statistic(trim_hcal_C_S_1a, trim_norm_1a, bins=nbin, statistic='std')
bin_width = (bin_edges[1] - bin_edges[0])
bin_centers = bin_edges[1:] - bin_width/2.

# plot trim
plt.figure()
plt.plot(trim_hcal_C_S_1a, trim_norm_1a, 'b.', label='data')
plt.errorbar(x=bin_centers, y=mean, yerr=rms, linestyle='none', marker='.', color='r', label='profile')
T_fit = np.interp(bin_centers,bin_centers,mean)
plt.plot(bin_centers[1:12],T_fit[1:12],linestyle='-',marker='',color='green',label='interp')
plt.legend()


# fit
x = bin_centers[1:12]
y = mean[1:12]
yerr = rms[1:12]/np.sqrt(count[1:12])
def fit_function(t, c1, c2, c3):
    return c1+c2*t+c3*t**2 #np.exp(t/c3)
params_1a, covars_1a = curve_fit(f=fit_function,
                           xdata=x,
                           ydata=y,
                           p0=(y[0]/2.,y[0]/2.,(x[-1]-x[0])/2.),
                           sigma=yerr,
                           #absolute_sigma=True
                          )
errs_1a = np.sqrt(np.diag(covars_1a))
print(params_1a[0],'+/-',errs_1a[0])
print(params_1a[1],'+/-',errs_1a[1])
print(params_1a[2],'+/-',errs_1a[2])
T_fit_1a = fit_function(x,params_1a[0],params_1a[1],params_1a[2])
plt.plot(x,T_fit_1a,linestyle='-',marker='',color='m',label='fit')
plt.xlabel('HCAL C/S',  fontname = "Times New Roman")
plt.ylabel('HCAL S/E',  fontname = "Times New Roman")
plt.title('Edep_HCAL/Beam Energy vs. HCAL C/S',  fontname = "Times New Roman")
chi2 = np.sum(((y-T_fit_1a)/yerr)**2)
dof = len(y) - len(params_1a)
pvalue = st.chi2.sf(chi2,dof)
print(chi2,dof,pvalue)

plt.legend()


# In[498]:


# define functions 
def fit_function(t, c1, c2, c3):
    return c1+c2*t+c3*t**2 #np.exp(t/c3)


# In[499]:


# define functions
# trim

def trim_data_x(x,y,nbin):
    mean, bin_edges, binnumber = st.binned_statistic(x, y, bins=nbin, statistic='mean');
    
    trim_index = np.where((y <= 0.7*mean[binnumber-1]) )[0]
    trim_x = x[trim_index];
    trim_y = y[trim_index];
    
    return trim_x
    
def trim_data_y(x,y,nbin):
    mean, bin_edges, binnumber = st.binned_statistic(x, y, bins=nbin, statistic='mean');
    
    trim_index = np.where((y <= 0.7*mean[binnumber-1]))[0]
    trim_y = y[trim_index];
    
    return trim_y


def trim_stats_count(trim_x, trim_y):
    count, bin_edges, binnumber = st.binned_statistic(trim_x, trim_y, bins=nbin, statistic='count')
    mean, bin_edges, binnumber = st.binned_statistic(trim_x, trim_y, bins=nbin, statistic='mean')
    rms, bin_edges, binnumber = st.binned_statistic(trim_x, trim_y, bins=nbin, statistic='std')
    bin_width = (bin_edges[1] - bin_edges[0])
    bin_centers = bin_edges[1:] - bin_width/2.
    
    T_fit = np.interp(bin_centers,bin_centers,mean)
    
    return [count,mean,rms,bin_centers, T_fit] 

def trim_stats_binwidth(trim_x, trim_y):
    count, bin_edges, binnumber = st.binned_statistic(trim_x, trim_y, bins=nbin, statistic='count')
    mean, bin_edges, binnumber = st.binned_statistic(trim_x, trim_y, bins=nbin, statistic='mean')
    rms, bin_edges, binnumber = st.binned_statistic(trim_x, trim_y, bins=nbin, statistic='std')
    bin_width = (bin_edges[1] - bin_edges[0])
    bin_centers = bin_edges[1:] - bin_width/2.
    
    T_fit = np.interp(bin_centers,bin_centers,mean)
    
    return bin_width 

def fitxy(bin_centers, mean, rms, count):
    x = bin_centers[1:12]
    y = mean[1:12]
    yerr = rms[1:12]/np.sqrt(count[1:12])
    
    return [x,y,yerr]


# In[500]:


# 1b) plot tot_cher_HCAL/inputEnergy versus hcal_C_S 
# fit a function to this curve (suggest using only beam energies of 5 and higher)


# In[501]:


#a) plot the tot_Edep_HCAL/inputEnergy vs. hcal_C_S

tot_Edep_HCAL_1a = dro_firstloop[:,3];
tot_cher_HCAL_1a = dro_firstloop[:,4];

hcal_C_S_1a = tot_cher_HCAL_1a/tot_Edep_HCAL_1a

# beam Energy 
beamEnergy = dro_firstloop[:,0] + mk0l;

# ratio
norm_1a = tot_cher_HCAL_1a/beamEnergy

#initial plot
plt.plot(hcal_C_S_1a, norm_1a, '.')

# plot trim
nbin=16;
mean, bin_edges, binnumber = st.binned_statistic(hcal_C_S_1a, norm_1a, bins=nbin, statistic='mean') # 
print(len(norm_1a), len(binnumber), np.min(binnumber), np.max(binnumber))

# trim
trim_index = np.where(norm_1a >= 0.8*mean[binnumber-1])[0]
trim_hcal_C_S_1a = hcal_C_S_1a[trim_index]
trim_norm_1a = norm_1a[trim_index]

count, bin_edges, binnumber = st.binned_statistic(trim_hcal_C_S_1a, trim_norm_1a, bins=nbin, statistic='count')
mean, bin_edges, binnumber = st.binned_statistic(trim_hcal_C_S_1a, trim_norm_1a, bins=nbin, statistic='mean')
rms, bin_edges, binnumber = st.binned_statistic(trim_hcal_C_S_1a, trim_norm_1a, bins=nbin, statistic='std')
bin_width = (bin_edges[1] - bin_edges[0])
bin_centers = bin_edges[1:] - bin_width/2.

# plot trim
plt.figure()
plt.plot(trim_hcal_C_S_1a, trim_norm_1a, 'b.', label='data')
plt.errorbar(x=bin_centers, y=mean, yerr=rms, linestyle='none', marker='.', color='r', label='profile')
T_fit = np.interp(bin_centers,bin_centers,mean)
plt.plot(bin_centers[1:12],T_fit[1:12],linestyle='-',marker='',color='green',label='interp')
plt.legend()


# fit
x = bin_centers[1:12]
y = mean[1:12]
yerr = rms[1:12]/np.sqrt(count[1:12])
def fit_function(t, c1, c2, c3):
    return c1+c2*t+c3*t**2 #np.exp(t/c3)
params, covars = curve_fit(f=fit_function,
                           xdata=x,
                           ydata=y,
                           p0=(y[0]/2.,y[0]/2.,(x[-1]-x[0])/2.),
                           sigma=yerr,
                           #absolute_sigma=True
                          )
errs = np.sqrt(np.diag(covars))
print(params[0],'+/-',errs[0])
print(params[1],'+/-',errs[1])
print(params[2],'+/-',errs[2])
T_fit = fit_function(x,params[0],params[1],params[2])
plt.plot(x,T_fit,linestyle='-',marker='',color='m',label='fit')
plt.xlabel('HCAL C/S',  fontname = "Times New Roman")
plt.ylabel('HCAL C/E',  fontname = "Times New Roman")
plt.title('Cher_HCAL/Beam Energy vs. HCAL C/S',  fontname = "Times New Roman")
chi2 = np.sum(((y-T_fit)/yerr)**2)
dof = len(y) - len(params)
pvalue = st.chi2.sf(chi2,dof)
print(chi2,dof,pvalue)

plt.legend()


# In[224]:


# second loop over all files
# 2) check that hcal correction applied to same sample of 1) gives corrected energy versus hcal_C_S
#    a) for the same sample of 1) plot (calibrated tot_Edep_HCAL)/inputEnergy and fit Gaussian to this distribution for each beam energy separately
#    b) for the same sample of 1) plot (calibrated tot_cher_HCAL)/inputEnergy and fit Gaussian to this distribution for each beam energy separately
#    c) at end of loop, plot Gaussian sigmas versus beam energy for a) and b)
# third loop over all files


# In[225]:


# Fit functions
def Gaussian(x,a,b,c):
    return a * np.exp(-(x - b)**2.0 / (2 * c**2))


# In[226]:


def residual(p, x, y):
    return Gaussian(x, *p) - y


# In[239]:


#a) for each beam energy 

def plot_2a_energy(energyValue, nbin):
    inputEnergy_1 = np.where(dro_firstloop[:,0]==energyValue)[0]

    # data
    tot_Edep_HCAL_2a = dro_firstloop[inputEnergy_1,3];
    tot_cher_HCAL_2a = dro_firstloop[inputEnergy_1,4];
    
    raw_plot_2a = tot_Edep_HCAL_2a

    hcal_C_S_2a = tot_cher_HCAL_2a/tot_Edep_HCAL_2a

    #calibrate
    T_fit_2a = fit_function(hcal_C_S_2a,params_1a[0],params_1a[1],params_1a[2])

    plt.figure()
    # the histogram of the data
    n, bins, patches = plt.hist(raw_plot_2a, nbin, alpha=0.75)

    # Generate data from bins as a set of points 
    bin_size = abs(bins[1]-bins[0])
    x = np.linspace(bins[0]+bin_size/2.0,bins[-2]+bin_size/2.0, len(bins)-1);
    y = n;

    popt, pcov = curve_fit(Gaussian,x,y)
    errs_gauss = np.sqrt(np.diag(pcov)) 
    print(popt[0],'+/-',errs_gauss[0])
    print('mu = ',popt[1],'+/-',errs_gauss[1])
    print('sigma = ',popt[2],'+/-',errs_gauss[2])
    print('entries = ', len(bins)-1)


    # Plot the fit
    x_fit = np.linspace(x[0], x[-1], len(bins)-1)
    y_gauss = Gaussian(x_fit, *popt)
    # y_boot = Gaussian(x_fit, *pfit_bootstrap)
    #yerr=Gaussian(x_fit,*err_curvefit)
    plt.plot(x_fit, y_gauss,linestyle='--',linewidth=2,    color='red',label='Gaussian')
    plt.xlabel('Calibrated S/E',  fontname = "Times New Roman")
    plt.ylabel('Frequency',  fontname = "Times New Roman")
    plt.title('Raw Edep HCAL/Beam Energy: '+ str(energyValue)+'GeV',  fontname = "Times New Roman")

    
    plt.text(0,100, 'Entries = ' + str(len(inputEnergy_1)) + '\n' + 'Bin Size = ' + str(round(bin_size, 6)) + '\n' + 'Sigma = ' + str(round(popt[2],6)) + '\n'+ 'Mu = ' + str(round(popt[1],6)) + '\n')
    
    return [popt[2],errs_gauss[2],popt[1],errs_gauss[1]]


# In[240]:


ene = np.asarray(ene)
sample1_ene = ene[np.where(ene >= minEnergy)[0]]
for i in range(len(sample1_ene)):
    energyValue = sample1_ene[i]
    nbin = 80
    plot_2a_energy(energyValue, nbin)


# In[502]:


#a) for each beam energy 

def calibrate_2a_energy(energyValue, nbin):
    inputEnergy_1 = np.where((dro_firstloop[:,0]==energyValue))[0]
    beamEnergyValue = energyValue + mk0l

    # data
    tot_Edep_HCAL_2a = dro_firstloop[inputEnergy_1,3];
    tot_cher_HCAL_2a = dro_firstloop[inputEnergy_1,4];

    hcal_C_S_2a = tot_cher_HCAL_2a/tot_Edep_HCAL_2a

    #calibrate
    T_fit_2a = tot_Edep_HCAL_2a/fit_function(hcal_C_S_2a,params_1a[0],params_1a[1],params_1a[2])
    T_fit_2a = T_fit_2a[np.where(T_fit_2a > 0.8 * energyValue)]

    plt.figure()
    # the histogram of the data
    n, bins, patches = plt.hist(T_fit_2a, nbin, alpha=0.75)

    # Generate data from bins as a set of points 
    bin_size = abs(bins[1]-bins[0])
    x = np.linspace(bins[0]+bin_size/2.0,bins[-2]+bin_size/2.0, len(bins)-1);
    y = n;

    popt, pcov = curve_fit(Gaussian,x,y,[100,energyValue,10])
    errs_gauss = np.sqrt(np.diag(pcov)) 
    print(popt[0],'+/-',errs_gauss[0])
    print('mu = ',popt[1],'+/-',errs_gauss[1])
    print('sigma = ',popt[2],'+/-',errs_gauss[2])
    print('entries = ', len(bins)-1)


    # Plot the fit
    x_fit = np.linspace(x[0], x[-1], len(bins)-1)
    y_gauss = Gaussian(x_fit, *popt)
    # y_boot = Gaussian(x_fit, *pfit_bootstrap)
    #yerr=Gaussian(x_fit,*err_curvefit)
    plt.plot(x_fit, y_gauss,linestyle='--',linewidth=2,    color='red',label='Gaussian')
    plt.xlabel('Calibrated S/E',  fontname = "Times New Roman")
    plt.ylabel('Frequency',  fontname = "Times New Roman")
    plt.title('Corrected Edep HCAL: '+ str(energyValue)+'GeV',  fontname = "Times New Roman")

    
    plt.text(0,100, 'Entries = ' + str(len(inputEnergy_1)) + '\n' + 'Bin Size = ' + str(round(bin_size, 6)) + '\n' + 'Sigma = ' + str(round(popt[2],6)) + '\n'+ 'Mu = ' + str(round(popt[1],6)) + '\n')
    
    return [popt[2],errs_gauss[2],popt[1],errs_gauss[1]]


# In[503]:


ene = np.asarray(ene)
sample1_ene = ene[np.where(ene >= minEnergy)[0]]
for i in range(len(sample1_ene)):
    energyValue = sample1_ene[i]
    nbin = 80
    calibrate_2a_energy(energyValue, nbin)


# In[254]:


#a) for each beam energy 

def calibrate_2a_energy_2(energyValue, nbin):
    inputEnergy_1 = np.where((dro_firstloop[:,0]==energyValue))[0]
    beamEnergyValue = energyValue + mk0l

    # data
    tot_Edep_HCAL_2a = dro_firstloop[inputEnergy_1,3];
    tot_cher_HCAL_2a = dro_firstloop[inputEnergy_1,4];

    hcal_C_S_2a = tot_cher_HCAL_2a/tot_Edep_HCAL_2a

    #calibrate
    T_fit_2a = tot_Edep_HCAL_2a/fit_function(hcal_C_S_2a,params_1a[0],params_1a[1],params_1a[2])
    T_fit_2a = T_fit_2a[np.where(T_fit_2a > 0.8 * energyValue)]/beamEnergyValue

    plt.figure()
    # the histogram of the data
    n, bins, patches = plt.hist(T_fit_2a, nbin, alpha=0.75)

    # Generate data from bins as a set of points 
    bin_size = abs(bins[1]-bins[0])
    x = np.linspace(bins[0]+bin_size/2.0,bins[-2]+bin_size/2.0, len(bins)-1);
    y = n;

    popt, pcov = curve_fit(Gaussian,x,y,[100,1.2,1])
    errs_gauss = np.sqrt(np.diag(pcov)) 
    print(popt[0],'+/-',errs_gauss[0])
    print('mu = ',popt[1],'+/-',errs_gauss[1])
    print('sigma = ',popt[2],'+/-',errs_gauss[2])
    print('entries = ', len(bins)-1)


    # Plot the fit
    x_fit = np.linspace(x[0], x[-1], len(bins)-1)
    y_gauss = Gaussian(x_fit, *popt)
    # y_boot = Gaussian(x_fit, *pfit_bootstrap)
    #yerr=Gaussian(x_fit,*err_curvefit)
    plt.plot(x_fit, y_gauss,linestyle='--',linewidth=2,    color='red',label='Gaussian')
    plt.xlabel('Calibrated S/E',  fontname = "Times New Roman")
    plt.ylabel('Frequency',  fontname = "Times New Roman")
    plt.title('Calibrated Edep HCAL/Beam Energy: '+ str(energyValue)+'GeV',  fontname = "Times New Roman")

    
    plt.text(0,100, 'Entries = ' + str(len(inputEnergy_1)) + '\n' + 'Bin Size = ' + str(round(bin_size, 6)) + '\n' + 'Sigma = ' + str(round(popt[2],6)) + '\n'+ 'Mu = ' + str(round(popt[1],6)) + '\n')
    
    return [popt[2],errs_gauss[2],popt[1],errs_gauss[1]]


ene = np.asarray(ene)
sample1_ene = ene[np.where(ene >= minEnergy)[0]]
for i in range(len(sample1_ene)):
    energyValue = sample1_ene[i]
    nbin = 80
    calibrate_2a_energy_2(energyValue, nbin)


# In[506]:


#a) for each beam energy 

def calibrate_2b_energy(energyValue, nbin):
    inputEnergy_1 = np.where(dro_firstloop[:,0]==energyValue)[0]
    beamEnergyValue = energyValue + mk0l

    # data
    tot_Edep_HCAL_2a = dro_firstloop[inputEnergy_1,3];
    tot_cher_HCAL_2a = dro_firstloop[inputEnergy_1,4];

    hcal_C_S_2a = tot_cher_HCAL_2a/tot_Edep_HCAL_2a

    #calibrate
    #T_fit_2a = fit_function(hcal_C_S_2a,params[0],params[1],params[2])
    
     #calibrate
    T_fit_2a = tot_cher_HCAL_2a/fit_function(hcal_C_S_2a,params[0],params[1],params[2])
    T_fit_2a = T_fit_2a[np.where(T_fit_2a > 0.8 * energyValue)]

    plt.figure()
    # the histogram of the data
    n, bins, patches = plt.hist(T_fit_2a, nbin, alpha=0.75)

    # Generate data from bins as a set of points 
    bin_size = abs(bins[1]-bins[0])
    x = np.linspace(bins[0]+bin_size/2.0,bins[-2]+bin_size/2.0, len(bins)-1);
    y = n;

    popt, pcov = curve_fit(Gaussian,x,y, [100,energyValue,1])
    errs_gauss = np.sqrt(np.diag(pcov)) 
    print(popt[0],'+/-',errs_gauss[0])
    print('mu = ',popt[1],'+/-',errs_gauss[1])
    print('sigma = ',popt[2],'+/-',errs_gauss[2])
    print('entries = ', len(bins)-1)


    # Plot the fit
    x_fit = np.linspace(x[0], x[-1], len(bins)-1)
    y_gauss = Gaussian(x_fit, *popt)
    # y_boot = Gaussian(x_fit, *pfit_bootstrap)
    #yerr=Gaussian(x_fit,*perr_curvefit)
    plt.plot(x_fit, y_gauss,linestyle='--',linewidth=2,    color='red',label='Gaussian')
    plt.xlabel('Calibrated HCAL C/E',  fontname = "Times New Roman")
    plt.ylabel('Frequency',  fontname = "Times New Roman")
    plt.title('Corrected HCAL Cherenkov Deposition: '+ str(energyValue)+'GeV',  fontname = "Times New Roman")

    
    plt.text(0,0, 'Entries = ' + str(len(inputEnergy_1)) + '\n' + 'Bin Size = ' + str(round(bin_size, 6)) + '\n' + 'Sigma = ' + str(round(popt[2],6)) + '\n'+ 'Mu = ' + str(round(popt[1],6)) + '\n')
    
    return [popt[2],errs_gauss[2],popt[1],errs_gauss[1]]


# In[507]:


ene = np.asarray(ene)
sample1_ene = ene[np.where(ene >= minEnergy)[0]]
for i in range(len(sample1_ene)):
    energyValue = sample1_ene[i]
    nbin = 80
    calibrate_2b_energy(energyValue, nbin)


# In[552]:


# plot the Gaussian sigmas versus beam energy 
#a 
def calibrate_2a_energy_noplot(energyValue, nbin):
    inputEnergy_1 = np.where(dro_firstloop[:,0]==energyValue)[0]

    # data
    tot_Edep_HCAL_2a = dro_firstloop[inputEnergy_1,3];
    tot_cher_HCAL_2a = dro_firstloop[inputEnergy_1,4];

    hcal_C_S_2a = tot_cher_HCAL_2a/tot_Edep_HCAL_2a

    #calibrate
    #calibrate
    T_fit_2a = tot_Edep_HCAL_2a/fit_function(hcal_C_S_2a,params_1a[0],params_1a[1],params_1a[2])
    T_fit_2a = T_fit_2a[np.where(T_fit_2a > 0.8 * energyValue)]

    n, bins, patches = plt.hist(T_fit_2a, nbin, alpha=0.75, fill=False, linewidth=0)

    # Generate data from bins as a set of points 
    bin_size = abs(bins[1]-bins[0])
    x = np.linspace(bins[0]+bin_size/2.0,bins[-2]+bin_size/2.0, len(bins)-1);
    y = n;

    popt, pcov = curve_fit(Gaussian,x,y, [100,energyValue,1])
    errs_gauss = np.sqrt(np.diag(pcov)) 
    return [abs(popt[2])/energyValue,errs_gauss[2]/energyValue]

def calibrate_2b_energy_noplot(energyValue, nbin):
    inputEnergy_1 = np.where(dro_firstloop[:,0]==energyValue)[0]

    # data
    tot_Edep_HCAL_2a = dro_firstloop[inputEnergy_1,3];
    tot_cher_HCAL_2a = dro_firstloop[inputEnergy_1,4];

    hcal_C_S_2a = tot_cher_HCAL_2a/tot_Edep_HCAL_2a

    #calibrate
    T_fit_2a = tot_cher_HCAL_2a/fit_function(hcal_C_S_2a,params[0],params[1],params[2])
    T_fit_2a = T_fit_2a[np.where(T_fit_2a > 0.8 * energyValue)]

    n, bins, patches = plt.hist(T_fit_2a, nbin, alpha=0.75, fill=False, linewidth=0)

    # Generate data from bins as a set of points 
    bin_size = abs(bins[1]-bins[0])
    x = np.linspace(bins[0]+bin_size/2.0,bins[-2]+bin_size/2.0, len(bins)-1);
    y = n;

    popt, pcov = curve_fit(Gaussian,x,y,[100,energyValue,1])
    errs_gauss = np.sqrt(np.diag(pcov)) 
    return [abs(popt[2]/energyValue),errs_gauss[2]/energyValue]


# In[547]:


ene = np.asarray(ene)
sample1_ene = ene[np.where(ene >= minEnergy)[0]]
sample1_sigma = np.zeros(len(sample1_ene));
norm_sigma1 = np.zeros(len(sample1_ene));
sample1_sigma_error = np.zeros(len(sample1_ene));

for i in range(len(sample1_ene)):
    energyValue = sample1_ene[i]
    nbin = 80
    sample1_sigma[i] = calibrate_2a_energy_noplot(energyValue, nbin)[0]
    sample1_sigma_error[i] = calibrate_2a_energy_noplot(energyValue, nbin)[1]
    
print(sample1_sigma_error)


# In[549]:


plt.plot(sample1_ene, sample1_sigma, '.--')
plt.errorbar(x=sample1_ene, y=sample1_sigma, yerr=sample1_sigma_error, linestyle='none', marker='.', color='r', label='profile')
plt.xlabel('Beam Energy (GeV)',  fontname = "Times New Roman")
plt.ylabel('Resolution (Delta(E)/E)',  fontname = "Times New Roman")
plt.title('Gaussian Sigma as a function of Beam Energy: Calibrated Total Deposited HCAL Energy (S) ',  fontname = "Times New Roman")


# In[554]:


ene = np.asarray(ene)
sample1_ene = ene[np.where(ene >= minEnergy)[0]]
sample1_sigma_cher = np.zeros(len(sample1_ene));
sample1_sigma_cher_error = np.zeros(len(sample1_ene));
norm_sigma2 = np.zeros(len(sample1_ene));

for i in range(len(sample1_ene)):
    energyValue = sample1_ene[i]
    nbin = 80
    sample1_sigma_cher[i] = calibrate_2b_energy_noplot(energyValue, nbin)[0]
    sample1_sigma_cher_error[i] = calibrate_2b_energy_noplot(energyValue, nbin)[1]

plt.figure()
plt.plot(sample1_ene, sample1_sigma_cher, '.--')
plt.errorbar(x=sample1_ene, y=sample1_sigma_cher, yerr=sample1_sigma_cher_error, linestyle='none', marker='.', color='r', label='profile')
plt.xlabel('Beam Energy (GeV)',  fontname = "Times New Roman")
plt.ylabel('Resolution (sigma(E)/E)(%)',  fontname = "Times New Roman")
plt.title('Gaussian Sigma as a function of Beam Energy: Calibrated Total Deposited HCAL Cherenkov ',  fontname = "Times New Roman")


# In[555]:


# third loop over all files
# 3) make weighted combination of calibrated tot_HCAL = [(calibrated tot_Edep_HCAL)/sigma(calibrated tot_Edep_HCAL)^2 + (calibrated tot_cher_HCAL)/sigma(calibrated tot_cher_HCAL)^2]/[1/sigma(calibrated tot_Edep_HCAL)^2 + 1/sigma(calibrated tot_cher_HCAL)^2]
#    a) plot tot_Edep_ECAL/(inputEnergy-calibrated tot_HCAL) versus ecal_C_S and fit a function to this curve (suggest using only beam energies of 10 and higher)
#    b) plot tot_cher_ECAL/(inputEnergy-calibrated tot_HCAL) versus ecal_C_S and fit a function to this curve (suggest using only beam energies of 10 and higher)
#    c) at end of loop, plot Gaussian sigmas versus beam energy for a) and b)


# In[633]:


minEnergy = 15.0
index = np.where((inputEnergy >= minEnergy) & (tot_Edep_HCAL > 0.0)& (tot_Edep_ECAL > 1.0))[0]
dro_thirdloop = dro[index,:];

tot_Edep_HCAL_3a = dro_thirdloop[:,3];
tot_cher_HCAL_3a = dro_thirdloop[:,4];
tot_cher_ECAL_3a = dro_thirdloop[:,2];
tot_Edep_ECAL_3a = dro_thirdloop[:,1]
input_energy_3a = dro_thirdloop[:,0];
beamEnergy_3a = input_energy_3a + mk0l;

hcal_C_S_3a = tot_cher_HCAL_3a/tot_Edep_HCAL_3a
ECAL_C_S_3 = np.asarray(tot_cher_ECAL_3a)/np.asarray(tot_Edep_ECAL_3a)

T_fit_3a_Edep = tot_Edep_HCAL_3a/fit_function(hcal_C_S_3a,params_1a[0],params_1a[1],params_1a[2])
T_fit_3a_Cher = tot_cher_HCAL_3a/fit_function(hcal_C_S_3a,params[0],params[1],params[2])

total_events = len(T_fit_3a_Edep);
sigma_HCAL_Edep = np.zeros(total_events)
sigma_HCAL_Cher = np.zeros(total_events)

for i in range(total_events):
    if input_energy_3a[i] == 15.0:
        sigma_HCAL_Edep[i] = sample1_sigma[0];
        sigma_HCAL_Cher[i] = sample1_sigma_cher[0];
    elif input_energy_3a[i] == 30.0:
        sigma_HCAL_Edep[i] = sample1_sigma[1];
        sigma_HCAL_Cher[i] = sample1_sigma_cher[1];
    elif input_energy_3a[i] == 60.0:
        sigma_HCAL_Edep[i] = sample1_sigma[2];
        sigma_HCAL_Cher[i] = sample1_sigma_cher[2];
    elif input_energy_3a[i] == 120.0:
        sigma_HCAL_Edep[i] = sample1_sigma[3];
        sigma_HCAL_Cher[i] = sample1_sigma_cher[3];
        

tot_HCAL_Calibrated = (T_fit_3a_Edep/sigma_HCAL_Edep**2 + T_fit_3a_Cher/sigma_HCAL_Cher**2)/(1/sigma_HCAL_Edep**2 + 1/sigma_HCAL_Cher**2)

choose_index = np.where(tot_HCAL_Calibrated < 0.9*beamEnergy_3a)
tot_HCAL_Cal_CUT = tot_HCAL_Calibrated[choose_index]
input_energy_3a_CUT = input_energy_3a[choose_index]+mk0l
tot_Edep_ECAL_3a_CUT = tot_Edep_ECAL_3a[choose_index]
tot_cher_ECAL_3a_CUT = tot_cher_ECAL_3a[choose_index]
ECAL_C_S_3_CUT = ECAL_C_S_3[choose_index]


# In[634]:


# plot
norm_3a = np.asarray(tot_Edep_ECAL_3a_CUT)/np.asarray((input_energy_3a_CUT-tot_HCAL_Cal_CUT))
#norm_3b = tot_cher_ECAL_3a/(inputEnergy_3a-tot_HCAL_Calibrated)
print(np.shape(tot_Edep_ECAL_3a_CUT))
print(np.shape(ECAL_C_S_3_CUT))


# In[635]:


plt.plot(ECAL_C_S_3_CUT,norm_3a, '.')


# In[636]:


def trim_data_x(x,y,nbin):
    mean, bin_edges, binnumber = st.binned_statistic(x, y, bins=nbin, statistic='mean');
    
    trim_index = np.where((y <= 1.5*mean[binnumber-1]) & (y >=  0.6*mean[binnumber-1]))[0]
    trim_x = x[trim_index];
    trim_y = y[trim_index];
    
    return trim_x
    
def trim_data_y(x,y,nbin):
    mean, bin_edges, binnumber = st.binned_statistic(x, y, bins=nbin, statistic='mean');
    
    trim_index = np.where((y <= 1.5*mean[binnumber-1])& (y >=  0.6*mean[binnumber-1]))[0]
    trim_y = y[trim_index];
    
    return trim_y


# In[637]:


nbin = 16;
ECS_new = trim_data_x(ECAL_C_S_3_CUT,norm_3a,nbin)
norm3a_new = trim_data_y(ECAL_C_S_3_CUT,norm_3a,nbin)


# In[638]:


plt.figure()
nbin = 16;

count, bin_edges, binnumber = st.binned_statistic(ECS_new, norm3a_new, bins=nbin, statistic='count')
mean, bin_edges, binnumber = st.binned_statistic(ECS_new, norm3a_new, bins=nbin, statistic='mean')
rms, bin_edges, binnumber = st.binned_statistic(ECS_new, norm3a_new, bins=nbin, statistic='std')
bin_width = (bin_edges[1] - bin_edges[0])
bin_centers = bin_edges[1:] - bin_width/2.



plt.plot(ECS_new,norm3a_new, 'b.', label='data')
plt.errorbar(x=bin_centers[1:14], y=mean[1:14], yerr=rms[1:14], linestyle='none', marker='.', color='r', label='profile')
P_fit = np.interp(bin_centers,bin_centers,mean)
plt.plot(bin_centers[1:14],P_fit[1:14],linestyle='-',marker='',color='green',label='interp')
plt.legend()


# fit
x = bin_centers[1:14]
y = mean[1:14]
yerr = rms[1:14]/np.sqrt(count[1:14])

def fit_function(t, c1, c2, c3):
    return c1+c2*t+c3*t**2 #np.exp(t/c3)

params_new, covars_new = curve_fit(f=fit_function,
                           xdata=x,
                           ydata=y,
                           p0=(y[0]/2.,y[0]/2.,(x[-1]-x[0])/2.),
                           sigma=yerr,
                           #absolute_sigma=True
                          )

errs_new = np.sqrt(np.diag(covars_new))
print(params_new[0],'+/-',errs_new[0])
print(params_new[1],'+/-',errs_new[1])
print(params_new[2],'+/-',errs_new[2])
PP_fit = fit_function(x,params_new[0],params_new[1],params_new[2])
plt.plot(x,PP_fit,linestyle='-',marker='',color='m',label='fit')
plt.xlabel('ECAL C/S',  fontname = "Times New Roman")
plt.ylabel('ECAL S/(Beam Energy - Calibrated HCAL)',  fontname = "Times New Roman")
plt.title('ECAL Deposited Energy/(Beam Energy - Calibrated HCAL)',  fontname = "Times New Roman")
chi2 = np.sum(((y-PP_fit)/yerr)**2)
dof = len(y) - len(params_new)
pvalue = st.chi2.sf(chi2,dof)
print(chi2,dof,pvalue)

plt.legend()


# In[639]:


norm_3b = np.asarray(tot_cher_ECAL_3a_CUT)/np.asarray((input_energy_3a_CUT-tot_HCAL_Cal_CUT))
nbin = 16;
ECS_new = trim_data_x(ECAL_C_S_3_CUT,norm_3b,nbin)
norm3a_new = trim_data_y(ECAL_C_S_3_CUT,norm_3b,nbin)


plt.figure()
nbin = 16;

count, bin_edges, binnumber = st.binned_statistic(ECS_new, norm3a_new, bins=nbin, statistic='count')
mean, bin_edges, binnumber = st.binned_statistic(ECS_new, norm3a_new, bins=nbin, statistic='mean')
rms, bin_edges, binnumber = st.binned_statistic(ECS_new, norm3a_new, bins=nbin, statistic='std')
bin_width = (bin_edges[1] - bin_edges[0])
bin_centers = bin_edges[1:] - bin_width/2.



plt.plot(ECS_new,norm3a_new, 'b.', label='data')
plt.errorbar(x=bin_centers[1:14], y=mean[1:14], yerr=rms[1:14], linestyle='none', marker='.', color='r', label='profile')
P_fit = np.interp(bin_centers,bin_centers,mean)
plt.plot(bin_centers[1:14],P_fit[1:14],linestyle='-',marker='',color='green',label='interp')
plt.legend()


# fit
x = bin_centers[1:14]
y = mean[1:14]
yerr = rms[1:14]/np.sqrt(count[1:14])

def fit_function(t, c1, c2, c3):
    return c1+c2*t+c3*t**2 #np.exp(t/c3)

params_new2, covars_new2 = curve_fit(f=fit_function,
                           xdata=x,
                           ydata=y,
                           p0=(y[0]/2.,y[0]/2.,(x[-1]-x[0])/2.),
                           sigma=yerr,
                           #absolute_sigma=True
                          )

errs_new2 = np.sqrt(np.diag(covars_new2))
print(params_new2[0],'+/-',errs_new2[0])
print(params_new2[1],'+/-',errs_new2[1])
print(params_new2[2],'+/-',errs_new2[2])
PP_fit = fit_function(x,params_new2[0],params_new2[1],params_new2[2])
plt.plot(x,PP_fit,linestyle='-',marker='',color='m',label='fit')
plt.xlabel('ECAL C/S',  fontname = "Times New Roman")
plt.ylabel('ECAL C/(Beam Energy - Calibrated HCAL)',  fontname = "Times New Roman")
plt.title('ECAL Cherenkov Energy/(Beam Energy - Calibrated HCAL)',  fontname = "Times New Roman")
chi2 = np.sum(((y-PP_fit)/yerr)**2)
dof = len(y) - len(params_new)
pvalue = st.chi2.sf(chi2,dof)
print(chi2,dof,pvalue)

plt.legend()


# In[640]:


#a) for each beam energy 

def plot_3a_energy(energyValue, nbin):
    inputEnergy_1 = np.where(dro_thirdloop[:,0]==energyValue)[0]

    # data
    tot_Edep_HCAL_3a = dro_thirdloop[inputEnergy_1,3];
    tot_cher_HCAL_3a = dro_thirdloop[inputEnergy_1,4];
    tot_cher_ECAL_3a = dro_thirdloop[inputEnergy_1,2];
    tot_Edep_ECAL_3a = dro_thirdloop[inputEnergy_1,1]
    input_energy_3a = dro_thirdloop[inputEnergy_1,0];
    tot_HCAL_Calibrated_3a = tot_HCAL_Calibrated[inputEnergy_1];
    beamEnergy_3a = input_energy_3a + mk0l;

    ecal_C_S_3a = tot_cher_ECAL_3a/tot_Edep_ECAL_3a
    beamEnergyValue = energyValue + mk0l
    
     #calibrate
    T_fit_3a = tot_Edep_ECAL_3a/fit_function(ecal_C_S_3a,params_new[0],params_new[1],params_new[2]) + tot_HCAL_Calibrated_3a
    T_fit_3a = T_fit_3a[np.where(T_fit_3a > 0.5 * beamEnergyValue)]


    plt.figure()
    # the histogram of the data
    n, bins, patches = plt.hist(T_fit_3a, nbin, alpha=0.75)

    # Generate data from bins as a set of points 
    bin_size = abs(bins[1]-bins[0])
    x = np.linspace(bins[0]+bin_size/2.0,bins[-2]+bin_size/2.0, len(bins)-1);
    y = n;

    popt, pcov = curve_fit(Gaussian,x,y,[100,beamEnergyValue,1])
    errs_gauss = np.sqrt(np.diag(pcov)) 
    print(popt[0],'+/-',errs_gauss[0])
    print('mu = ',popt[1],'+/-',errs_gauss[1])
    print('sigma = ',popt[2],'+/-',errs_gauss[2])
    print('entries = ', len(bins)-1)


    # Plot the fit
    x_fit = np.linspace(x[0], x[-1], len(bins)-1)
    y_gauss = Gaussian(x_fit, *popt)
    # y_boot = Gaussian(x_fit, *pfit_bootstrap)
    #yerr=Gaussian(x_fit,*err_curvefit)
    plt.plot(x_fit, y_gauss,linestyle='--',linewidth=2,    color='red',label='Gaussian')
    plt.xlabel('S/E (with Calibrated HCAL)',  fontname = "Times New Roman")
    plt.ylabel('Frequency',  fontname = "Times New Roman")
    plt.title('Calibrated S/E: Third Loop: '+ str(energyValue)+'GeV',  fontname = "Times New Roman")

    
    plt.text(0,100, 'Entries = ' + str(len(inputEnergy_1)) + '\n' + 'Bin Size = ' + str(round(bin_size, 6)) + '\n' + 'Sigma = ' + str(round(popt[2],6)) + '\n'+ 'Mu = ' + str(round(popt[1],6)) + '\n')
    
    return [popt[2],errs_gauss[2],popt[1],errs_gauss[1]]


# In[641]:


ene = np.asarray(ene)
sample1_ene = ene[np.where(ene >= minEnergy)[0]]
for i in range(len(sample1_ene)):
    energyValue = sample1_ene[i]
    nbin = 80
    plot_3a_energy(energyValue, nbin)


# In[642]:


#a) for each beam energy 

def plot_3b_energy(energyValue, nbin):
    inputEnergy_1 = np.where(dro_thirdloop[:,0]==energyValue)[0]

    # data
    tot_Edep_HCAL_3a = dro_thirdloop[inputEnergy_1,3];
    tot_cher_HCAL_3a = dro_thirdloop[inputEnergy_1,4];
    tot_cher_ECAL_3a = dro_thirdloop[inputEnergy_1,2];
    tot_Edep_ECAL_3a = dro_thirdloop[inputEnergy_1,1]
    input_energy_3a = dro_thirdloop[inputEnergy_1,0];
    tot_HCAL_Calibrated_3a = tot_HCAL_Calibrated[inputEnergy_1];
    beamEnergy_3a = input_energy_3a + mk0l;

    ecal_C_S_3a = tot_cher_ECAL_3a/tot_Edep_ECAL_3a
    beamEnergyValue = energyValue + mk0l
    
     #calibrate
    T_fit_3a = tot_cher_ECAL_3a/fit_function(ecal_C_S_3a,params_new2[0],params_new2[1],params_new2[2]) + tot_HCAL_Calibrated_3a
    T_fit_3a = T_fit_3a[np.where(T_fit_3a > 0.5 * beamEnergyValue)]

    plt.figure()
    # the histogram of the data
    n, bins, patches = plt.hist(T_fit_3a, nbin, alpha=0.75)

    # Generate data from bins as a set of points 
    bin_size = abs(bins[1]-bins[0])
    x = np.linspace(bins[0]+bin_size/2.0,bins[-2]+bin_size/2.0, len(bins)-1);
    y = n;

    popt, pcov = curve_fit(Gaussian,x,y, [100, beamEnergyValue, 1])
    errs_gauss = np.sqrt(np.diag(pcov)) 
    print(popt[0],'+/-',errs_gauss[0])
    print('mu = ',popt[1],'+/-',errs_gauss[1])
    print('sigma = ',popt[2],'+/-',errs_gauss[2])
    print('entries = ', len(bins)-1)


    # Plot the fit
    x_fit = np.linspace(x[0], x[-1], len(bins)-1)
    y_gauss = Gaussian(x_fit, *popt)
    # y_boot = Gaussian(x_fit, *pfit_bootstrap)
    #yerr=Gaussian(x_fit,*err_curvefit)
    plt.plot(x_fit, y_gauss,linestyle='--',linewidth=2,    color='red',label='Gaussian')
    plt.xlabel('C/E (Calibrated HCAL)',  fontname = "Times New Roman")
    plt.ylabel('Frequency',  fontname = "Times New Roman")
    plt.title('Calibrated Cherenkov ECAL/E: Third Loop: '+ str(energyValue)+'GeV',  fontname = "Times New Roman")

    
    plt.text(0,100, 'Entries = ' + str(len(inputEnergy_1)) + '\n' + 'Bin Size = ' + str(round(bin_size, 6)) + '\n' + 'Sigma = ' + str(round(popt[2],6)) + '\n'+ 'Mu = ' + str(round(popt[1],6)) + '\n')
    
    return [popt[2],errs_gauss[2],popt[1],errs_gauss[1]]


# In[643]:


ene = np.asarray(ene)
sample1_ene = ene[np.where(ene >= minEnergy)[0]]
for i in range(len(sample1_ene)):
    energyValue = sample1_ene[i]
    nbin = 80
    plot_3b_energy(energyValue, nbin)


# In[655]:


# plot the Gaussian sigmas versus beam energy 
#a 
def calibrate_3b_energy_noplot(energyValue, nbin):
    inputEnergy_1 = np.where(dro_thirdloop[:,0]==energyValue)[0]

    # data
    tot_Edep_HCAL_3a = dro_thirdloop[inputEnergy_1,3];
    tot_cher_HCAL_3a = dro_thirdloop[inputEnergy_1,4];
    tot_cher_ECAL_3a = dro_thirdloop[inputEnergy_1,2];
    tot_Edep_ECAL_3a = dro_thirdloop[inputEnergy_1,1]
    input_energy_3a = dro_thirdloop[inputEnergy_1,0];
    tot_HCAL_Calibrated_3a = tot_HCAL_Calibrated[inputEnergy_1];
    beamEnergy_3a = input_energy_3a + mk0l;

    ecal_C_S_3a = tot_cher_ECAL_3a/tot_Edep_ECAL_3a
    beamEnergyValue = energyValue + mk0l
    
     #calibrate
    T_fit_3a = tot_cher_ECAL_3a/fit_function(ecal_C_S_3a,params_new2[0],params_new2[1],params_new2[2]) + tot_HCAL_Calibrated_3a
    T_fit_3a = T_fit_3a[np.where(T_fit_3a > 0.5 * beamEnergyValue)]/beamEnergyValue

    #plt.figure()
    # the histogram of the data
    n, bins, patches = plt.hist(T_fit_3a, nbin, alpha=0.75)

    # Generate data from bins as a set of points 
    bin_size = abs(bins[1]-bins[0])
    x = np.linspace(bins[0]+bin_size/2.0,bins[-2]+bin_size/2.0, len(bins)-1);
    y = n;

    popt, pcov = curve_fit(Gaussian,x,y, [100, 1.0, 1])
    errs_gauss = np.sqrt(np.diag(pcov)) 
    return [abs(popt[2]),errs_gauss[1]]


def calibrate_3a_energy_noplot(energyValue, nbin):
    inputEnergy_1 = np.where(dro_thirdloop[:,0]==energyValue)[0]

    # data
    tot_Edep_HCAL_3a = dro_thirdloop[inputEnergy_1,3];
    tot_cher_HCAL_3a = dro_thirdloop[inputEnergy_1,4];
    tot_cher_ECAL_3a = dro_thirdloop[inputEnergy_1,2];
    tot_Edep_ECAL_3a = dro_thirdloop[inputEnergy_1,1]
    input_energy_3a = dro_thirdloop[inputEnergy_1,0];
    tot_HCAL_Calibrated_3a = tot_HCAL_Calibrated[inputEnergy_1];
    beamEnergy_3a = input_energy_3a + mk0l;

    ecal_C_S_3a = tot_cher_ECAL_3a/tot_Edep_ECAL_3a
    beamEnergyValue = energyValue + mk0l
    
     #calibrate
    T_fit_3a = tot_Edep_ECAL_3a/fit_function(ecal_C_S_3a,params_new[0],params_new[1],params_new[2]) + tot_HCAL_Calibrated_3a
    T_fit_3a = T_fit_3a[np.where(T_fit_3a > 0.5 * beamEnergyValue)]/beamEnergyValue


    #plt.figure()
    # the histogram of the data
    n, bins, patches = plt.hist(T_fit_3a, nbin, alpha=0.75)

    # Generate data from bins as a set of points 
    bin_size = abs(bins[1]-bins[0])
    x = np.linspace(bins[0]+bin_size/2.0,bins[-2]+bin_size/2.0, len(bins)-1);
    y = n;

    popt, pcov = curve_fit(Gaussian,x,y,[100,1.0,1])
    errs_gauss = np.sqrt(np.diag(pcov)) 
    return [abs(popt[2]),errs_gauss[1]]


# In[656]:


ene = np.asarray(ene)
sample1_ene = ene[np.where(ene >= minEnergy)[0]]
sample2_sigma_cher = np.zeros(len(sample1_ene));
sample2_sigma_cher_error = np.zeros(len(sample1_ene));
norm_sigma2 = np.zeros(len(sample1_ene));

for i in range(len(sample1_ene)):
    energyValue = sample1_ene[i]
    nbin = 80
    sample2_sigma_cher[i] = calibrate_3b_energy_noplot(energyValue, nbin)[0]
    sample2_sigma_cher_error[i] = calibrate_3b_energy_noplot(energyValue, nbin)[1];
    

print(sample2_sigma_cher_error)
plt.figure()
plt.plot(sample1_ene, sample2_sigma_cher, '.--')
plt.errorbar(x=sample1_ene, y=sample2_sigma_cher, yerr=sample2_sigma_cher_error, linestyle='none', marker='.', color='r', label='profile')
plt.xlabel('Beam Energy (GeV)',  fontname = "Times New Roman")
plt.ylabel('Resolution (sigma/E)(%)',  fontname = "Times New Roman")
plt.title('Gaussian Sigma as a function of Beam Energy: Calibrated Total HCAL: Deposited ECAL Cherenkov ',  fontname = "Times New Roman")


# In[657]:


ene = np.asarray(ene)
sample1_ene = ene[np.where(ene >= minEnergy)[0]]
sample2_sigma = np.zeros(len(sample1_ene));
sample2_sigma_cher_error = np.zeros(len(sample1_ene));
norm_sigma2 = np.zeros(len(sample1_ene));

for i in range(len(sample1_ene)):
    energyValue = sample1_ene[i]
    nbin = 80
    sample2_sigma[i] = calibrate_3a_energy_noplot(energyValue, nbin)[0]
    sample2_sigma_cher_error[i] = calibrate_3a_energy_noplot(energyValue, nbin)[1];

plt.figure()
plt.plot(sample1_ene, sample2_sigma, '.--')
plt.errorbar(x=sample1_ene, y=sample2_sigma, yerr=sample2_sigma_cher_error, linestyle='none', marker='.', color='r', label='profile')
plt.xlabel('Beam Energy (GeV)',  fontname = "Times New Roman")
plt.ylabel('Resolution (%)',  fontname = "Times New Roman")
plt.title('Gaussian Sigma as a function of Beam Energy: Calibrated HCAL: Total Deposited ECAL ',  fontname = "Times New Roman")


# In[585]:


# make weighted combination of total ECAL 
minEnergy = 15.0
index = np.where((inputEnergy >= minEnergy) & (tot_Edep_HCAL > 0.0)& (tot_Edep_ECAL > 0.0))[0]
dro_fourthloop = dro[index,:];

tot_Edep_HCAL_4a = dro_fourthloop[:,3];
tot_cher_HCAL_4a = dro_fourthloop[:,4];
tot_cher_ECAL_4a = dro_fourthloop[:,2];
tot_Edep_ECAL_4a = dro_fourthloop[:,1];
input_energy_4a = dro_fourthloop[:,0];
beamEnergy_4a = input_energy_4a + mk0l;

hcal_C_S_4 = tot_cher_HCAL_4a/tot_Edep_HCAL_4a
ecal_C_S_4 = tot_cher_ECAL_4a/tot_Edep_ECAL_4a

T_fit_4a_Edep = tot_Edep_HCAL_4a/fit_function(hcal_C_S_4,params_1a[0],params_1a[1],params_1a[2])
T_fit_4a_Cher = tot_cher_HCAL_4a/fit_function(hcal_C_S_4,params[0],params[1],params[2])

P_fit_4a_Edep = tot_Edep_ECAL_4a/fit_function(ecal_C_S_4,params_new[0],params_new[1],params_new[2])
P_fit_4a_Cher = tot_cher_ECAL_4a/fit_function(ecal_C_S_4,params_new2[0],params_new2[1],params_new2[2])


total_events = len(T_fit_4a_Edep);
sigma_HCAL_Edep = np.zeros(total_events)
sigma_HCAL_Cher = np.zeros(total_events)
sigma_ECAL_Edep = np.zeros(total_events)
sigma_ECAL_Cher = np.zeros(total_events)

for i in range(total_events):
    if input_energy_4a[i] == 15.0:
        sigma_HCAL_Edep[i] = sample1_sigma[0];
        sigma_HCAL_Cher[i] = sample1_sigma_cher[0];
        sigma_ECAL_Edep[i] = sample2_sigma[0];
        sigma_ECAL_Cher[i] = sample2_sigma_cher[0];
    elif input_energy_4a[i] == 30.0:
        sigma_HCAL_Edep[i] = sample1_sigma[1];
        sigma_HCAL_Cher[i] = sample1_sigma_cher[1];
        sigma_ECAL_Edep[i] = sample2_sigma[1];
        sigma_ECAL_Cher[i] = sample2_sigma_cher[1];
    elif input_energy_4a[i] == 60.0:
        sigma_HCAL_Edep[i] = sample1_sigma[2];
        sigma_HCAL_Cher[i] = sample1_sigma_cher[2];
        sigma_ECAL_Edep[i] = sample2_sigma[2];
        sigma_ECAL_Cher[i] = sample2_sigma_cher[2];
    elif input_energy_4a[i] == 120.0:
        sigma_HCAL_Edep[i] = sample1_sigma[3];
        sigma_HCAL_Cher[i] = sample1_sigma_cher[3];
        sigma_ECAL_Edep[i] = sample2_sigma[3];
        sigma_ECAL_Cher[i] = sample2_sigma_cher[3];
        

tot_HCAL_Calibrated = (T_fit_4a_Edep/sigma_HCAL_Edep**2 + T_fit_4a_Cher/sigma_HCAL_Cher**2)/(1/sigma_HCAL_Edep**2 + 1/sigma_HCAL_Cher**2)
tot_ECAL_Calibrated = (P_fit_4a_Edep/sigma_ECAL_Edep**2 + P_fit_4a_Cher/sigma_ECAL_Cher**2)/(1/sigma_ECAL_Edep**2 + 1/sigma_ECAL_Cher**2)

tot_Cal_energy = tot_HCAL_Calibrated+tot_ECAL_Calibrated


# In[586]:


print(tot_Cal_energy)


# In[595]:


# loop over energies separately

#a) for each beam energy 

def plot_4_energy(energyValue, nbin):
    inputEnergy_1 = np.where(dro_fourthloop[:,0]==energyValue)[0]

    # data
    tot_Edep_HCAL_4a = dro_fourthloop[inputEnergy_1,3];
    tot_cher_HCAL_4a = dro_fourthloop[inputEnergy_1,4];
    tot_cher_ECAL_4a = dro_fourthloop[inputEnergy_1,2];
    tot_Edep_ECAL_4a = dro_fourthloop[inputEnergy_1,1];
    input_energy_4a = dro_fourthloop[inputEnergy_1,0];
    beamEnergy_4a = input_energy_4a + mk0l;
    
     #calibrate
    final_energy = tot_Cal_energy[inputEnergy_1];
    final_energy = final_energy[np.where(final_energy >= 0.7*beamEnergy_4a)]

    plt.figure()
    # the histogram of the data
    n, bins, patches = plt.hist(final_energy, nbin, alpha=0.75)

    # Generate data from bins as a set of points 
    bin_size = abs(bins[1]-bins[0])
    x = np.linspace(bins[0]+bin_size/2.0,bins[-2]+bin_size/2.0, len(bins)-1);
    y = n;

    popt, pcov = curve_fit(Gaussian,x,y,[100, energyValue, 1])
    errs_gauss = np.sqrt(np.diag(pcov)) 
    print(popt[0],'+/-',errs_gauss[0])
    print('mu = ',popt[1],'+/-',errs_gauss[1])
    print('sigma = ',popt[2],'+/-',errs_gauss[2])
    print('entries = ', len(bins)-1)


    # Plot the fit
    x_fit = np.linspace(x[0], x[-1], len(bins)-1)
    y_gauss = Gaussian(x_fit, *popt)
    # y_boot = Gaussian(x_fit, *pfit_bootstrap)
    #yerr=Gaussian(x_fit,*err_curvefit)
    plt.plot(x_fit, y_gauss,linestyle='--',linewidth=2,    color='red',label='Gaussian')
    plt.xlabel('Calibrated Total Energy (GeV)',  fontname = "Times New Roman")
    plt.ylabel('Frequency',  fontname = "Times New Roman")
    plt.title('Total Calibrated Energy (ECAL + HCAL)/Beam Energy: '+ str(energyValue)+'GeV',  fontname = "Times New Roman")

    
    plt.text(0,100, 'Entries = ' + str(len(inputEnergy_1)) + '\n' + 'Bin Size = ' + str(round(bin_size, 6)) + '\n' + 'Sigma = ' + str(round(popt[2],6)) + '\n'+ 'Mu = ' + str(round(popt[1],6)) + '\n')
    
    return [popt[2],errs_gauss[2],popt[1],errs_gauss[1]]


# In[596]:


ene = np.asarray(ene)
sample1_ene = ene[np.where(ene >= minEnergy)[0]]
for i in range(len(sample1_ene)):
    energyValue = sample1_ene[i]
    nbin = 80
    plot_4_energy(energyValue, nbin)


# In[664]:


# plot the Gaussian sigmas versus beam energy 
#a 
def calibrate_4_energy_noplot(energyValue, nbin):
    beamEnergyValue = energyValue + mk0l;
    inputEnergy_1 = np.where(dro_fourthloop[:,0]==energyValue)[0]

    # data
    tot_Edep_HCAL_4a = dro_fourthloop[inputEnergy_1,3];
    tot_cher_HCAL_4a = dro_fourthloop[inputEnergy_1,4];
    tot_cher_ECAL_4a = dro_fourthloop[inputEnergy_1,2];
    tot_Edep_ECAL_4a = dro_fourthloop[inputEnergy_1,1];
    input_energy_4a = dro_fourthloop[inputEnergy_1,0];
    beamEnergy_4a = input_energy_4a + mk0l;
    
     #calibrate
    final_energy = tot_Cal_energy[inputEnergy_1];
    final_energy = final_energy[np.where(final_energy >= 0.7*beamEnergy_4a)]

    #plt.figure()
    # the histogram of the data
    n, bins, patches = plt.hist(final_energy, nbin, alpha=0.75)

    # Generate data from bins as a set of points 
    bin_size = abs(bins[1]-bins[0])
    x = np.linspace(bins[0]+bin_size/2.0,bins[-2]+bin_size/2.0, len(bins)-1);
    y = n;

    popt, pcov = curve_fit(Gaussian,x,y,[100,beamEnergyValue,1])
    errs_gauss = np.sqrt(np.diag(pcov)) 
    return [abs(popt[2])/np.sqrt(beamEnergyValue**2),errs_gauss[2]/np.sqrt(beamEnergyValue)]

ene = np.asarray(ene)
sample1_ene = ene[np.where(ene >= minEnergy)[0]]
sample_sigma = np.zeros(len(sample1_ene));
sample_sigma_cher_error = np.zeros(len(sample1_ene));
norm_sigma = np.zeros(len(sample1_ene));

for i in range(len(sample1_ene)):
    energyValue = sample1_ene[i]
    nbin = 80
    sample_sigma[i] = calibrate_4_energy_noplot(energyValue, nbin)[0]
    sample_sigma_cher_error[i] = calibrate_4_energy_noplot(energyValue, nbin)[1];

plt.figure()
plt.plot(sample1_ene, sample_sigma, '.--')
plt.errorbar(x=sample1_ene, y=sample_sigma, yerr=sample_sigma_cher_error, linestyle='none', marker='.', color='r', label='profile')
plt.xlabel('Beam Energy (GeV)',  fontname = "Times New Roman")
plt.ylabel('Relative Resolutiono',  fontname = "Times New Roman")
plt.title('Gaussian Sigma as a function of Beam Energy: Calibrated Total Deposited ECAL ',  fontname = "Times New Roman")


plt.figure()
plt.plot(sample1_ene, sample_sigma*np.sqrt(sample1_ene), '.--')
plt.errorbar(x=sample1_ene, y=sample_sigma*np.sqrt(sample1_ene), yerr=sample_sigma_cher_error*np.sqrt(sample1_ene), linestyle='none', marker='.', color='r', label='profile')
plt.xlabel('Beam Energy (GeV)',  fontname = "Times New Roman")
plt.ylabel('Resolution (%/Sqrt(E))',  fontname = "Times New Roman")
plt.title('Gaussian Sigma as a function of Beam Energy: Calibrated Total Deposited ECAL ',  fontname = "Times New Roman")


# In[ ]:





# In[ ]:




