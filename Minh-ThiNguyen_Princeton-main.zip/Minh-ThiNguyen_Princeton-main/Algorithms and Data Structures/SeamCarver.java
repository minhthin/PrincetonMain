/* *****************************************************************************
 *  Name:    Minh-Thi
 *  NetID:   
 *  Precept: 
 *
 *  Description: Implements seam carver for a 2D picture
 *
 **************************************************************************** */

import edu.princeton.cs.algs4.IndexMinPQ;
import edu.princeton.cs.algs4.Picture;

public class SeamCarver {
    // create a seam carver object based on the given picture
    private int height;
    private int width;

    // save picture features
    private Picture picture;
    private double[][] energy;

    private static double finalEnergy = 100000.0;


    public SeamCarver(Picture picture) {
        height = picture.height();
        width = picture.width();
        this.picture = picture;
        energy = new double[width][height];

        // label energy of each pixel
        // compute energy of pixel


        // compute energy of each pixel and initialize
        for (int r = 0; r < height; r++) {
            for (int c = 0; c < width; c++) {
                energy[c][r] = energy(c, r);
            }
        }

    }

    // current picture
    public Picture picture() {
        return picture;
    }

    // width of current picture
    public int width() {
        return width;
    }

    // height of current picture
    public int height() {
        return height;
    }

    // get red, green, blue colors at column x and row y
    private double[] getColor(int x, int y) {
        double[] getColorRGB = new double[3];

        getColorRGB[0] = picture.get(x, y).getRed();
        getColorRGB[1] = picture.get(x, y).getGreen();
        getColorRGB[2] = picture.get(x, y).getBlue();

        return getColorRGB;
    }

    // compute magnitude of the difference between two arrays
    private double magnitudeDifference(double[] array1, double[] array2) {
        double sum = 0;
        if (array1.length != array2.length) throw new
                IllegalArgumentException("Arrays must be same length.");

        for (int i = 0; i < array1.length; i++) {
            sum = sum + (array1[i] - array2[i]) * (array1[i] - array2[i]);
        }
        return Math.sqrt(sum);
    }

    // energy of pixel at column x and row y
    public double energy(int x, int y) {
        double[] xLeft;
        double[] xRight;

        if (x != 0 && x != width - 1) {
            xLeft = getColor(x - 1, y);
            xRight = getColor(x + 1, y);


        }
        else if (x == 0) {
            xLeft = getColor(width - 1, y);
            xRight = getColor(x + 1, y);

        }

        else {
            xLeft = getColor(x - 1, y);
            xRight = getColor(0, y);

        }

        // x gradient
        double xGradient = magnitudeDifference(xLeft, xRight);


        double[] yTop;
        double[] yBottom;

        // compute the y gradient
        if (y != 0 && y != height - 1) {
            yTop = getColor(x, y - 1);
            yBottom = getColor(x, y + 1);
        }
        else if (y == 0) {
            yTop = getColor(x, height - 1);
            yBottom = getColor(x, y + 1);
        }
        else {
            yTop = getColor(x, y - 1);
            yBottom = getColor(x, 0);
        }

        // x gradient
        double yGradient = magnitudeDifference(yTop, yBottom);
        ;

        return Math.sqrt(xGradient * xGradient +
                                 yGradient * yGradient);

    }

    // translate to one dimension given column x and row y
    private int to1D(int x, int y) {
        return (y - 1) * width + x;
    }

    // sequence of indices for horizontal seam
    public int[] findHorizontalSeam() {
        // transpose the picture
        transposePicture();

        int[] horizontalSeam = findVerticalSeam();

        // transpose back
        transposePicture();

        return horizontalSeam;
    }

    // sequence of indices for vertical seam
    public int[] findVerticalSeam() {
        // use Dijkstra algorithm with virtual final node
        double[] distTo = new double[width * height + 1];
        int[] edgeTo = new int[width * height + 1];
        IndexMinPQ<Double> sPQ = new IndexMinPQ<Double>(width * height + 1);
        int[] finalSeam = new int[height];
        int[] verticalSeam = new int[height];

        for (int i = 0; i < distTo.length; i++) {
            distTo[i] = Double.POSITIVE_INFINITY;
        }

        // add first row to distTo and priority queue
        for (int i = 0; i < width; i++) {
            distTo[to1D(i, 0)] = energy(i, 0);
            sPQ.insert(to1D(i, 0), distTo[to1D(i, 0)]);
        }

        // complete algorithm
        while (!sPQ.isEmpty()) {
            int v = sPQ.delMin(); // remove the shortest distance
            int col = to2D(v)[0];
            int row = to2D(v)[1];
            int[] adjacent = adjacent(col, row);

            for (int i = 0; i < adjacent.length; i++) {
                int neighbor = adjacent[i];

                double neighborEnergy;
                if (neighbor != width * height) {
                    neighborEnergy =
                            energy(to2D(neighbor)[0], to2D(neighbor)[1]);
                }
                else neighborEnergy = finalEnergy;

                double distanceThroughVertex = distTo[v] + neighborEnergy;


                if (distanceThroughVertex < distTo[neighbor]) {
                    // update
                    distTo[neighbor] = distanceThroughVertex;
                    edgeTo[neighbor] = v;

                    // update priority queue
                    if (sPQ.contains(neighbor)) {
                        sPQ.decreaseKey(neighbor, distTo[neighbor]);
                    }
                    else {
                        sPQ.insert(neighbor, distTo[neighbor]);
                    }
                }
            }
        }

        // find the final seam by checking edgeTo
        // trace back from virtual bottom node
        finalSeam[0] = edgeTo[height * width];
        for (int i = 1; i < height; i++) {
            finalSeam[i] = edgeTo[finalSeam[i - 1]];
        }

        // return the sequence of indices for the vertical seam
        for (int i = height - 1; i >= 0; i--) {
            verticalSeam[i] = to2D(finalSeam[i])[0];
        }

        return verticalSeam;
    }


    // translate to 2D
    private int[] to2D(int n) {
        int[] xy = new int[2];
        // row
        int row = n / width;
        // col
        int col = n - row * width;

        xy[0] = col;
        xy[1] = row;

        return xy;
    }

    // nearest neighbors to column x and row y
    private int[] adjacent(int x, int y) {
        // if x, y in border
        if (leftEdgeBottom(x, y)) {
            int[] neighbors = new int[1];
            neighbors[0] = width * height;
            return neighbors;
        }
        else if (leftEdge(x, y)) {
            int[] neighbors = new int[2];
            neighbors[0] = to1D(x, y + 1);
            neighbors[1] = to1D(x + 1, y + 1);
            return neighbors;
        }
        else if (rightEdgeBottom(x, y)) {
            int[] neighbors = new int[1];
            neighbors[0] = width * height;
            return neighbors;
        }
        else if (rightEdge(x, y)) {
            int[] neighbors = new int[2];
            neighbors[0] = to1D(x, y + 1);
            neighbors[1] = to1D(x - 1, y + 1);
            return neighbors;
        }
        else if (middleBottom(x, y)) {
            int[] neighbors = new int[1];
            neighbors[0] = width * height;
            return neighbors;
        }
        else {
            int[] neighbors = new int[3];
            neighbors[0] = to1D(x, y + 1);
            neighbors[1] = to1D(x - 1, y + 1);
            neighbors[2] = to1D(x + 1, y + 1);
            return neighbors;
        }
    }

    // characterize point of col x and row y
    private boolean leftEdge(int x, int y) {
        if (x == 0 && y != height) return true;
        else return false;
    }

    // characterize point of col x and row y
    private boolean leftEdgeBottom(int x, int y) {
        if (x == 0 && y == height) return true;
        else return false;
    }

    // characterize point of col x and row y
    private boolean rightEdge(int x, int y) {
        if (x == width && y != height) return true;
        else return false;
    }

    // characterize point of col x and row y
    private boolean rightEdgeBottom(int x, int y) {
        if (x == width && y == height) return true;
        else return false;
    }

    // characterize point of col x and row y
    private boolean middleBottom(int x, int y) {
        if (x != 0 && x != width && y == height) return true;
        else return false;
    }


    // remove horizontal seam
    public void removeHorizontalSeam(int[] seam) {
        // transpose the picture
        transposePicture();

        removeVerticalSeam(seam);

        // transpose back
        transposePicture();

    }

    // remove vertical seam
    public void removeVerticalSeam(int[] seam) {
        // update the picture
        // update the energies
        // width = width - 1

        // create new picture array
        Picture newPicture = new Picture(width - 1, height);

        // traverse each row to update
        for (int r = 0; r < height; r++) {
            int c = 0;
            while (c != seam[r]) {
                newPicture.setRGB(c, r, picture.getRGB(c, r));
                c++;
            }
            for (int i = c; i < width - 1; i++) {
                newPicture.setRGB(i, r, picture.getRGB(i + 1, r));
            }
        }

        // update energies
        double[][] newEnergy = new double[width - 1][height];
        for (int r = 0; r < newPicture.height(); r++) {
            for (int c = 0; c < newPicture.width(); c++) {
                newEnergy[c][r] = energy(c, r);
            }
        }

        // update picture
        picture = newPicture;

        // update energies
        energy = newEnergy;

        // update width
        width--;
    }

    // transpose
    public void transposePicture() {
        Picture newPicture = new Picture(width, height);

        for (int c = 0; c < width; c++) {
            for (int r = 0; r < height; r++) {
                newPicture.setRGB(r, c, picture.getRGB(c, r));
            }
        }

        picture = newPicture;
    }

// unit testing
    public static void main(String[] args) {

    }
}
